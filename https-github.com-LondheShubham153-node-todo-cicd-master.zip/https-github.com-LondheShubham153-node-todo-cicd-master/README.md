# node-todo-cicd

sudo apt install nodejs
sudo apt install npm


npm install

node app.js

